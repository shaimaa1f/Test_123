﻿$TDT = New-Object -ComObject 'Toad.ToadAutoObject'                                   # Start TDT  

try
  {
         $TargetConnection = $TDT.Connections.NewConnection('QUEST/dev@PDBPROD')     # Target Schema credentials
         $ScriptInputFolder    = "C:\TDT\PoC\Output\SchemaCompare" 
         $ScriptOutputFolder   = "C:\TDT\PoC\Output\SchemaCompare" 
         $File                 = "ReleaseToProd.sql"
               
         $Script               = $TDT.Scripts.Add()
         $Script.Connection    = $TargetConnection
         $Script.IncludeOutput = $TRUE
         $Script.InputFile     = "$ScriptInputFolder\$File"
         $Script.OutputFile    = "$ScriptOutputFolder\Prod_release_log.txt"          # Log file
         $Script.Execute()
         $ScriptOutput = $Script.OutputText
   }

finally {
         $TDT.Quit()     # Stop TDT
        }

