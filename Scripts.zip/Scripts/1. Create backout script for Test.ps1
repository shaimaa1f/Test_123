$TDT = New-Object -ComObject 'Toad.ToadAutoObject'                                		# Start TDT  

try {
     # Make Connections to Source and Target Databases
     $Target = $TDT.Connections.NewConnection('QUEST/dev@PDBDEV')   	# Source Schema credentials
     $Source = $TDT.Connections.NewConnection('QUEST/dev@PDBTEST')    	# Target Schema credentials
     
     # Setting Source Connection Information
     $TDT.CompareSchemas.Source.Connection = $Source                # Set Source Connection info      
     $TDT.CompareSchemas.Source.Schema     = 'QUEST'        # Set Source Schema

     # Setting Target Connection Information
     $TDT.CompareSchemas.Target.Connection = $Target                # Set Target Connection info      
     $TDT.CompareSchemas.Target.Schema     = 'QUEST'        # Set Target Schema

     # Object Types to be included
     # Use "Include All", then, optionally, specify specific object types to exclude by setting them to $FALSE
     # To include a specific object type, remove the line of code or set it to $TRUE
     $TDT.CompareSchemas.ObjectTypes.IncludeAll()
     $TDT.CompareSchemas.ObjectTypes.SynonymsPrivate                = $FALSE
     $TDT.CompareSchemas.ObjectTypes.SynonymsPublic                 = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Directories                    = $FALSE
     $TDT.CompareSchemas.ObjectTypes.AuditPolicies                  = $FALSE
     $TDT.CompareSchemas.ObjectTypes.AuditPolicies                  = $FALSE
     $TDT.CompareSchemas.ObjectTypes.AuditsSQLPrivs                 = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Audits_All                     = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Audits_Selected                = $FALSE
     $TDT.CompareSchemas.ObjectTypes.CDBResourcePlans               = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Clusters                       = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Contexts                       = $FALSE
     $TDT.CompareSchemas.ObjectTypes.DBLinks                        = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Dimensions                     = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Editions                       = $FALSE
     $TDT.CompareSchemas.ObjectTypes.FlashbackArchives              = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Grants_All                     = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Grants_Selected                = $FALSE
     $TDT.CompareSchemas.ObjectTypes.InitParameters                 = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Java_Class                     = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Java_Resource                  = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Java_Source                    = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Jobs                           = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Libraries                      = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Outlines                       = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Partitions                     = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Policies                       = $FALSE               
     $TDT.CompareSchemas.ObjectTypes.PolicyGroups                   = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Profiles                       = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Queues                         = $FALSE
     $TDT.CompareSchemas.ObjectTypes.QueueTables                    = $FALSE
     $TDT.CompareSchemas.ObjectTypes.RedactionPolicies              = $FALSE
     $TDT.CompareSchemas.ObjectTypes.RedoLogs                       = $FALSE
     $TDT.CompareSchemas.ObjectTypes.RefreshGroups                  = $FALSE
     $TDT.CompareSchemas.ObjectTypes.ResourceConsumerGroups         = $FALSE
     $TDT.CompareSchemas.ObjectTypes.ResourcePlans                  = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Roles                          = $FALSE
     $TDT.CompareSchemas.ObjectTypes.RollbackSegments_Private       = $FALSE
     $TDT.CompareSchemas.ObjectTypes.RollbackSegments_Public        = $FALSE
     $TDT.CompareSchemas.ObjectTypes.SchedulerChains                = $FALSE
     $TDT.CompareSchemas.ObjectTypes.SchedulerCredentials           = $FALSE
     $TDT.CompareSchemas.ObjectTypes.SchedulerJobClasses            = $FALSE
     $TDT.CompareSchemas.ObjectTypes.SchedulerJobs                  = $FALSE
     $TDT.CompareSchemas.ObjectTypes.SchedulerPrograms              = $FALSE
     $TDT.CompareSchemas.ObjectTypes.SchedulerSchedules             = $FALSE
     $TDT.CompareSchemas.ObjectTypes.SchedulerWindowGroups          = $FALSE
     $TDT.CompareSchemas.ObjectTypes.SchedulerWindows               = $FALSE
     $TDT.CompareSchemas.ObjectTypes.SynonymsPrivate                = $FALSE
     $TDT.CompareSchemas.ObjectTypes.SynonymsPrivateForSchema       = $FALSE
     $TDT.CompareSchemas.ObjectTypes.SynonymsPublic                 = $FALSE
     $TDT.CompareSchemas.ObjectTypes.TypeBodies                     = $FALSE
     $TDT.CompareSchemas.ObjectTypes.Types                          = $FALSE
     $TDT.CompareSchemas.ObjectTypes.UnifiedAuditPolicies           = $FALSE
     $TDT.CompareSchemas.ObjectTypes.UnifiedAuditPoliciesEnablement = $FALSE
     $TDT.CompareSchemas.ObjectTypes.ZoneMaps                       = $FALSE


     # Run Schema Compare
     $TDT.CompareSchemas.Execute()

     # Directory & Filename of schema sync script with timestamp
     $CompareRunDate     = Get-Date -Format yyyyMMddHHmmss
     $CompareDir         = "C:\TDT\PoC\Output\SchemaCompare"
     $CompareFile        = 'Test_backout_script_'+$CompareRunDate+'.csv'
     $ComparePath        = "$CompareDir\$CompareFile"

     # Save CSV difference details to file
     $DifferenceDetailsCSV = $TDT.CompareSchemas.GetDifferenceDetailsCSV()
     $DifferenceDetailsCSV | Out-File -FilePath $ComparePath -Force

     # Directory & Filename of schema sync script with timestamp
     $SyncDir         = "C:\TDT\PoC\Output\SchemaCompare"
     $SyncFile        = 'Test_backout_script.sql'
     $SyncPath        = "$SyncDir\$SyncFile"

     # Save schema sync script to file
     $SyncScript = $TDT.CompareSchemas.GetScript()
     $SyncScript | Out-File -FilePath $SyncPath -Force
    }

finally {
         $TDT.Quit()     # Stop TDT
        }
