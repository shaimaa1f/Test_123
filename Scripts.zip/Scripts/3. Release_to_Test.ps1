﻿$TDT = New-Object -ComObject 'Toad.ToadAutoObject'                                # Start TDT  

try
  {
         $TargetConnection = $TDT.Connections.NewConnection('QUEST/dev@PDBTEST')
         $ScriptInputFolder    = "C:\TDT\PoC\Output\SchemaCompare" 
         $ScriptOutputFolder   = "C:\TDT\PoC\Output\SchemaCompare" 
         $File                 = "ReleaseToTest.sql"
               
         $Script               = $TDT.Scripts.Add()
         $Script.Connection    = $TargetConnection
         $Script.IncludeOutput = $TRUE
         $Script.InputFile     = "$ScriptInputFolder\$File"
         $Script.OutputFile    = "$ScriptOutputFolder\release_log.txt"
         $Script.Execute()
         $ScriptOutput = $Script.OutputText
   }

finally {
         $TDT.Quit()     # Stop TDT
        }

